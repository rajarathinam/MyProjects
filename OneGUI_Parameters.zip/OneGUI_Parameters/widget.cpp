#include "widget.h"
#include "ui_widget.h"
#include <QFontDatabase>

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    lineEdit = new MyLineEdit(this);
    lineEdit->setPlaceholderText("Search parameter");
    ui->pushButton_2->setFocus();

    ui->pushButton->setStyleSheet("font-family:FontAwesome;color:#999999;background:transparent");
    const QChar search(0xf002);

   ui->pushButton->setText(search);
    connect(ui->pushButton, SIGNAL(clicked(bool)),
            this, SLOT(searchClicked()));
    connect(lineEdit, SIGNAL(offFocus()),
            this,SLOT(onEditFinised()));
    connect(lineEdit, SIGNAL(onFocus()),
            this,SLOT(onTextChanged()));


}

Widget::~Widget()
{
    delete ui;
}

void Widget::searchClicked()
{
    ui->pushButton_2->setText(ui->lineEdit->text());
}

void Widget::onEditFinised()
{
   if(lineEdit->text().isEmpty())
   {
       const QChar search(0xf002);
       ui->pushButton->setText(search);

   } else
   {
       const QChar close(0xf00d);
       ui->pushButton->setText(close);

   }
}

void Widget::onTextChanged()
{
    if(lineEdit->text().isEmpty())
    {
        const QChar search(0xf002);
        ui->pushButton->setText(search);

    } else
    {
    const QChar clock(0xf017);
    ui->pushButton->setText(clock);
    }

}
