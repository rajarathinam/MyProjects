#include "mylineedit.h"

MyLineEdit::MyLineEdit(QWidget*)
{

}
void MyLineEdit::focusInEvent(QFocusEvent *e)
{
    QLineEdit::focusInEvent(e);
     emit onFocus();
}
void MyLineEdit::focusOutEvent(QFocusEvent *e)
{
    QLineEdit::focusOutEvent(e);
     emit offFocus();
}
