#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDropEvent>
#include <QDragEnterEvent>
#include <QMimeData>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow) {
    ui->setupUi(this);

    textedit = new TextEdit;
    textedit->setAcceptDrops(false);
    setCentralWidget(textedit);
    setAcceptDrops(true);

}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event) {
    //event->acceptProposedAction();
}

void MainWindow::dropEvent(QDropEvent *event) {
    QList<QUrl> list = event->mimeData()->urls();
    QString filename = list.first().toLocalFile();
    readFile(filename);


}

void MainWindow::readFile(const QString &filename)
{
    if(!filename.isEmpty())
    {
      QFile file(filename)  ;
      if(file.open(QIODevice::ReadOnly | QIODevice::Text))
      {
          QTextStream in(&file);
          QString all = in.readAll();
          textedit->setPlainText(all);
      }


    }

    }
