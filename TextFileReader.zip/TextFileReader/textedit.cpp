#include "textedit.h"

TextEdit::TextEdit()
{

}

TextEdit::~TextEdit()
{

}
