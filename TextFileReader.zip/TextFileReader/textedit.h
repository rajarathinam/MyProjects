#ifndef TEXTEDIT_H
#define TEXTEDIT_H

#include <QTextEdit>
class TextEdit : public QTextEdit
{
public:
    TextEdit();
    ~TextEdit();
};

#endif // TEXTEDIT_H
