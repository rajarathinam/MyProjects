#include "customprogressbar.h"

CustomProgressBar::CustomProgressBar(QWidget *parent) : QWidget(parent)
{
    layout = new QVBoxLayout;
    progressbar = new QProgressBar;
    slider = new QSlider(Qt::Horizontal);
    layout->addWidget(progressbar);
    layout->addWidget(slider);
    setLayout(layout);

    connect(slider, SIGNAL(valueChanged(int)),
            progressbar, SLOT(setValue(int)));

}

void CustomProgressBar::setValue(int value)
{
    slider->setValue(value);

}

int CustomProgressBar::value()
{
    return slider->value();

}

