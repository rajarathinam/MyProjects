#ifndef CUSTOMPROGRESSBAR_H
#define CUSTOMPROGRESSBAR_H

#include <QVBoxLayout>
#include <QSlider>
#include <QProgressBar>
class CustomProgressBar : public QWidget
{
    Q_OBJECT
public:
    explicit CustomProgressBar(QWidget *parent = 0);
    void setValue(int value);
    int value();

signals:

public slots:
private:
    QVBoxLayout *layout;
    QProgressBar *progressbar;
    QSlider *slider;

};

#endif // CUSTOMPROGRESSBAR_H
