#include "customitemdelegate.h"

CustomItemDelegate::CustomItemDelegate(QObject *parent)
    : QStyledItemDelegate(parent)
{
}
//! [0]

//! [1]
QWidget *CustomItemDelegate::createEditor(QWidget *parent,
    const QStyleOptionViewItem &/* option */,
    const QModelIndex &/* index */) const
{
   // QSpinBox *editor = new QSpinBox(parent);
    CustomProgressBar *editor = new CustomProgressBar(parent);



    return editor;
}
//! [1]

//! [2]
void CustomItemDelegate::setEditorData(QWidget *editor,
                                    const QModelIndex &index) const
{
    int value = index.model()->data(index, Qt::EditRole).toInt();

   /* QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
    spinBox->setValue(value);*/
    CustomProgressBar *progressbar = static_cast<CustomProgressBar*>(editor);
    progressbar->setValue(value);
}
//! [2]

//! [3]
void CustomItemDelegate::setModelData(QWidget *editor, QAbstractItemModel *model,
                                   const QModelIndex &index) const
{
    //QSpinBox *spinBox = static_cast<QSpinBox*>(editor);
    CustomProgressBar *progressbar = static_cast<CustomProgressBar*>(editor);
    //spinBox->interpretText();
    int value = progressbar->value();

    model->setData(index, value, Qt::EditRole);
}
//! [3]

//! [4]
void CustomItemDelegate::updateEditorGeometry(QWidget *editor,
    const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
    editor->setGeometry(option.rect);
}
//! [4]
