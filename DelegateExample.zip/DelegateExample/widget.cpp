#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    model = new QStandardItemModel;
    delegate = new CustomItemDelegate;
    model->setRowCount(10);
    model->setColumnCount(1);
       ui->tableView->setModel(model);
    for( int row = 0; row < model->rowCount(); ++row)
    {
        QStandardItem *item = new QStandardItem(QString::number(row));
        model->setItem(row, 0, item);
        ui->tableView->setRowHeight(row, 150);
    }


    ui->tableView->setItemDelegate(delegate);
}

Widget::~Widget()
{
    delete ui;
}
