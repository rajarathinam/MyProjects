#include "widget.h"
#include "ui_widget.h"
#include <QLabel>
#include <QVBoxLayout>
#include <QTimer>
#include <QScreen>
#include <QGuiApplication>
#include <QBitmap>
#include <QTime>
void delay()
{
QTime dieTime= QTime::currentTime().addSecs(0);
while (QTime::currentTime() < dieTime)
    QCoreApplication::processEvents(QEventLoop::AllEvents, 100);
}
Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    timer = new QTimer(this);
        timer->setInterval(1000);

        screenshotLabel = new QLabel;
        screenshotLabel->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        screenshotLabel->setAlignment(Qt::AlignCenter);
        screenshotLabel->setMinimumSize(240, 160);

        mainLayout = new QVBoxLayout;
        QBitmap map(300,300);
        screenshotLabel->setMask(map);


        mainLayout->addWidget(screenshotLabel);
        QPixmap mask("d:\\drill.png");
        ui->pushButton->setMask(mask.mask());
        setLayout(mainLayout);

       // connect(timer, SIGNAL(timeout()), SLOT(takeScreenShot()));

        timer->start();
}



Widget::~Widget()
{
    delete ui;
}
void Widget::takeScreenShot()
{
    originalPixmap = QPixmap();

    QScreen *screen = QGuiApplication::primaryScreen();
    if (screen)
    {
        originalPixmap = screen->grabWindow(0);
    }

    screenshotLabel->setPixmap(originalPixmap.scaled(screenshotLabel->size(),
                                                     Qt::KeepAspectRatio,
                                                     Qt::SmoothTransformation));
}


void Widget::load1()
{
    delay();
    emit loadUIs(QString("Loading UIs..."));
    delay();
    emit loadDBConnections(QString("Loading DBConnections..."));
    delay();
    emit loadGraphics(QString("Loading Graphics..."));
}
