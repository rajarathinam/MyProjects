#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QObject>
#include <QThread>
#include <QTime>
#include <QEventLoop>
#include <QCoreApplication>

void delay();
class MyThread : public QThread
{
    Q_OBJECT
public:
     MyThread();

    virtual void run()
    {
        for(int x = 0; x < 10000; ++x)
        {
            delay();
            emit data(x);
        }
    }
signals:
     void data(int x);

};

#endif // MYTHREAD_H
