#ifndef SPLASHWIDGET_H
#define SPLASHWIDGET_H

#include <QWidget>
#include "widget.h"
class Widget;
namespace Ui {
class splashwidget;
}

class splashwidget : public QWidget
{
    Q_OBJECT

public:
    explicit splashwidget(QWidget *parent = 0);
    void setMainWidget(Widget* in_widget);
    ~splashwidget();

private slots:
    void catchdata(QString);
private:
    Ui::splashwidget *ui;
    Widget* m_widget;


};

#endif // SPLASHWIDGET_H
