#include "splashwidget.h"
#include "ui_splashwidget.h"

splashwidget::splashwidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::splashwidget)
{
    ui->setupUi(this);
    m_widget = NULL;
}

void splashwidget::setMainWidget(Widget *in_widget)
{
    m_widget = in_widget;

}

splashwidget::~splashwidget()
{
    delete ui;
}

void splashwidget::catchdata(QString xx)
{
    ui->label->setText(xx);
    if(xx == "Loading Graphics...")
    {
        this->close();
    m_widget->setVisible(true);
    }
}
