#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include "splashwidget.h"

namespace Ui {
class Widget;
}
class QLabel;
class QVBoxLayout;
class QTimer;
class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    void load1();
    ~Widget();

private:
    Ui::Widget *ui;
private slots:
    void takeScreenShot();
signals:
    void loadUIs(QString);
    void loadDBConnections(QString);
    void loadGraphics(QString);
private:
    QLabel *screenshotLabel;
    QPixmap originalPixmap;
    QVBoxLayout *mainLayout;
    QTimer *timer;

};

#endif // WIDGET_H
