#include "widget.h"
#include <QApplication>
#include <QLabel>
#include <QPainter>
#include <QPushButton>
#include <QBitmap>
#include <QThread>
#include <QDebug>
#include "mythread.h"
#include "splashwidget.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    splashwidget w1;

    QObject::connect(&w, SIGNAL(loadUIs(QString)),
                     &w1, SLOT(catchdata(QString)));
    QObject::connect(&w, SIGNAL(loadDBConnections(QString)),
                     &w1, SLOT(catchdata(QString)));
    QObject::connect(&w, SIGNAL(loadGraphics(QString)),
                     &w1, SLOT(catchdata(QString)));
    w1.setMainWidget(&w);

    w1.show();
    w.load1();

    return a.exec();
}
